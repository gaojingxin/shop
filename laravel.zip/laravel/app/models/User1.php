<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class User1 extends Model
{
    protected $table="user1";
    public $timestamps="false";
}
