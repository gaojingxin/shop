<?php

namespace App\Http\Controllers\order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use App\models\User1;
use App\Http\Controllers\Controller;

class OrderController extends Controller
{
    public function show(){
        $arr="select * from user2 ";
        $res=DB::select($arr);
        return view("order.order",["desc"=>$res]);
    } 
    public function doadd(Request $request){
        $data=$request->input();
        //print_R($data);exit;
        $res=DB::table('user1')->insert($data);
        if($res){
          echo 1;
        }else{
          echo 2;
        }
      }
    
      //展示
    public function form(Request $request){
        $search=$request->input("is_sale");
        $arr=DB::table('user1')
        ->join('user2','user2.id','=','user1.id')
        ->whereOr('is_sale', '=', $search)
        ->paginate(2);
        // print_r($arr);die;
        foreach($arr as $k=>$v){
            if($v->is_hot==1){
                $arr[$k]->is_hot='√';
            }else{
                $arr[$k]->is_hot='×';
            }
            if($v->is_sale==1){
                $arr[$k]->is_sale='√';
            }else{
                $arr[$k]->is_sale='×';
            }
        }
        return view('order.form',['arr'=>$arr]);
    }
    //删除
    public function delete(Request $request){
        $goods_id=$request->input('id');
        $res=DB::table('user1')->where('user_id',$goods_id)->delete();
        if($res){
            return 1;
        }else{
            return 2;
        }
    }
    // 修改
    public function update(Request $request){
        $cate=DB::table('user2')->get();
        $id=$request->input('user_id');
        $arr=DB::table('user1')->where('user_id',$id)->first();
        return view('order.update',['arr'=>$arr],['cate'=>$cate]);
        
    }
    // 修改执行
    public function update_do(Request $request){
        $data=$request->input();
        $id=$data['user_id'];
        $res=DB::table('user1')->where('user_id',$id)->update($data);
        if($res){
            return 1;
        }else{
            return 2;
        }
    }
    // 即点即改商品名称
    public function upname(Request $request){
        $name=$request->input('user_name');
        $id=$request->input('id');
        $res=DB::table('user1')->where('user_id',$id)->update(['user_name'=>$name]);
        if($res){
            echo  1;
        }else{
            echo 2;
        }
    }
    public function user(){
        echo 2222;
    // // 查询
    //    $arr = User1::all();
    //    print_r($arr);
    // 添加
    // $name=array(
    //     'user_name'=>'list',
    //     'id'=>'1',
    //     'user_content'=>'qwqwkq',
    //     'is_hot'=>2,
    //     'is_sale'=>1,
    // );
    // $res=User1::insert($name);
    // echo $res;
    }
}
