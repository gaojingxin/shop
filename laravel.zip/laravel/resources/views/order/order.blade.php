<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form class="add_form" >
    <table border=1>
    <tr>
        <td>名称</td>
        <td><input type="text" name="user_name" id="txtUserName"></td>
    </tr>
    <tr>
        <td>分类</td>
        <td><select name="id" id="">
            <?php
                foreach ($desc as $key => $value){

               
            ?>
            <option value="<?php echo $value->id?>"><?php echo $value->name ?></option>
            <?php
                 }
            ?>
        </select></td>
    </tr>
    <tr>
        <td>描述</td>
        <td><textarea name="user_content" id="" cols="30" rows="10"></textarea></td>
    </tr>
    <tr>
        <td>是否热销</td>
        <td>
            <input type="radio" value="1" name="is_hot">是
            <input type="radio" value="2" name="is_hot">否
        </td>
    </tr>
    <tr>
        <td>是否上架</td>
        <td>
            <input type="radio" value="1" name="is_sale">是
            <input type="radio" value="2" name="is_sale">否
        </td>
    </tr>
    <tr>
        <td><input type="button" class="submit"  ></td>
    </tr>
    </table>
    </form>
</body>
</html> 
<script src="/js/jquery.js"></script>
<script>
	$(function(){
		$('.submit').click(function(){
			var form=$(".add_form").serialize();
			$.ajax({
				url:'doadd',
				data:form,
				method:'post',}).done(function(res){
					console.log(res);
					if(res==1){
						alert('添加成功');
						location.href='form';
					}else{
						alert('添加失败');
						location.href='add';
					}
				})
		});
	})
</script>