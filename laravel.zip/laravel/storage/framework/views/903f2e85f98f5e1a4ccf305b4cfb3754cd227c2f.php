<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="add" method="post">
    <table>
    <tr>
        <td>名称</td>
        <td><input type="text"></td>
    </tr>
    <tr>
        <td>分类</td>
        <td><select name="" id="">
            <option value="1">孙悟空</option>
            <option value="1">沙僧</option>
            <option value="1">猪八戒</option>
            <option value="1">唐僧</option>
        </select></td>
    </tr>
    <tr>
        <td></td>
        <td><input type="text"></td>
    </tr>
    <tr>
        <td><input type="submit" value="submit" ></td>
    </tr>
    </table>
    </form>
</body>
</html>