<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\models\Cart;
class IndexController extends Controller
{
    public static $arr=[];
    // 首页展示
    public function index(){
        $where=[
            'is_tell'=>1
        ];
        $arr=DB::table('goods')->where($where)->paginate(2);
        return view('index.index',["arr"=>$arr]); 
    }
    // 加载流
    public function addli(Request $request){
        $arr=array();
        $page=$request->input("page",1);
        $pageNum=2;
        $offset=($page-1)*$pageNum;
        $arrDataInfo=DB::table("goods")->offset($offset)->limit($pageNum)->get();//每页的数据

        $totalData=DB::table("goods")->count();
        $pageTotal=ceil($totalData/$pageNum);//总页数

        $objview=view("index.goodsli",['info'=>$arrDataInfo]);
        $content=response($objview)->getContent();

        $arr['info']=$content;
        $arr['page']=$pageTotal;
        return $arr;
    }
    // 获取分类列表
    public function allshops(){
        $where=[
            'pid'=>0,
        ];
        $arr=DB::table("category")->where($where)->get();
        $where=[
            'is_tell'=>1,
        ];
        $res=DB::table("goods")->where($where)->get();
        return view("index.allshops",['arr'=>$arr,'res'=>$res]);
    }
    // 点击分类循环数据
    public function test(Request $request){
        $arrIds=DB::table('category')->select("cate_id")->where("pid",0)->get();
        $cate_id=$request->input('id');
        // echo $cate_id;
        if(empty($cate_id)){
            $where=[
                'is_tell'=>1,
            ];
            $goodsInfo=DB::table("goods")->where($where)->get();
        }else{
            $this->get($cate_id);
            // var_dump($cate_id);die;
            array_unshift(self::$arr,$cate_id);
            $goodsInfo=DB::table('goods')->whereIn("cate_id",self::$arr)->get();
        }
        // var_dump($goodsInfo);
        $view=view("index.shopsli",['goodsInfo'=>$goodsInfo]);
        $content=response($view)->getContent();
        $arr['info']=$content;
        return $arr;
    }
    public function get($id){
        $arrNews=DB::table('category')->select("cate_id")->where("pid",$id)->get();
        if(count($arrNews)>0){
            foreach($arrNews as $key=>$value){
                $cateId=$value->cate_id;
                $arrids=$this->get($cateId);
            }
        }
        foreach($arrNews as $value){
            $cate_id=$value->cate_id;
            array_push(self::$arr,$cate_id);
        }
       
}
// 商品详情
public function shopContent(Request $request){
    $id=$request->input("id");
    $where=[
        'goods_id'=>$id,
    ];
    $arr=DB::table("goods")->where($where)->get();
    return view("index.shopcontent",['arr'=>$arr]);
}
public function qaz(){
    $arr=array(
        array("id"=>1,"name"=>"lisi","age"=>20),
        array("id"=>2,"name"=>"lisi","age"=>50),
        array("id"=>3,"name"=>"lisi","age"=>10),
        array("id"=>4,"name"=>"lisi","age"=>9),
        array("id"=>5,"name"=>"lisi","age"=>4),
    );
    $arrResult=array();
    foreach($arr as $key=>$value){
        $arrResult[$value['age']]=$value;
    }
    print_r($arrResult);die;
    $arrAge=array();
    foreach($arr as $key=>$value){
        $arrAge[]=$value['age'];
    }
    sort($arrAge);
    print_r($arrAge);die;

    $arrHandle=array();
    foreach($arrAge as $key=>$value){
        $arrHandle[]=$arrResult[$value];
    }
    print_r($arrHandle);
}
// 添加购物车
public function shopcart(Request $request){
    $id=$request->input("id");
    // echo $id;die;
    if(empty($id)){
        return array("status"=>0,"msg"=>"参数为空");
    }
    $uid = session("tel");
    if(empty($uid)){
        return array("status"=>0,"msg"=>"需登录");
    }else{
        $where=[
            'is_sell'=>1,
            "goods_id"=>$id,
        ];
        $arr=DB::table("goods")->where($where)->get();
        $arr=count($arr);
        // print_r($arr);die;
        if($arr==0){
            return array("status"=>1,"msg"=>"商品不存在");die;
        }
        $where=[
            'is_tell'=>1,
            "goods_id"=>$id,
        ];
        $arr=DB::table("goods")->where($where)->get();
        // var_dump($arr);die;
        $arr=count($arr);
        // print_r($arr);die;
        if($arr==0){
            return array("status"=>1,"msg"=>"商品未上架");die;
        }
        $where=[
            "goods_id"=>$id,
        ];
        $arr=DB::table("goods")->where($where)->first();
        $goods_pnum=$arr->goods_pnum;
        if($goods_pnum < 1){
            return array("status"=>2,"msg"=>"商品库存不足");die;
        }
        $where=[
            "goods_id"=>$id,
        ];
        $cart= DB::table('cart')->where($where)->first();
        // var_dump($cart);die;
        if($cart==NULL){
            $data=[];
            $data['goods_id']=$id;
            $data['user_id']=$uid;
            $data['number']=1;
            $data['ctime']=time();
            $data['status']=1;
            $data['goods_prices']=$arr->goods_price;
            $arr=DB::table('cart')->insert($data);
            if($arr){
                return array("status"=>3,"msg"=>"添加成功");   
            }  
        }else{
            $cart= DB::table('cart')->where($where)->first();
            $number=$cart->number;
            if($number>0){
                $num=$number+1;
                $cart= DB::table('cart')->where($where)->update(['number'=>$num]);
                return array("status"=>3,"msg"=>"添加成功");
                    
            }       
}
    }
}
//展示购物车列表
public function docart(){
    $where=[
        'status'=>1,
    ];
    $arr=DB::table("cart")->join("goods",'goods.goods_id','=','cart.goods_id')->where($where)->get();
    $where=[
        'is_hot'=>1
    ];
    $res=DB::table("goods")->where($where)->get();
    return view("index.shopcart",['arr'=>$arr,'res'=>$res]);
   
}
// 清除登录session
public function quit(Request $request){
    $request->session()->flush();
}
// 展示个人中心 我的潮购
public function userpage(){
    return view("index.userpage");
}
public function cart_del(Request $request){
    $cart_id=$request->input('cart_id');
    $arr=DB::table('cart')->whereIn('cart_id',$cart_id)->update(['status'=>0]);
    
    if($arr){
        return $info = [
            'status' => 1,
            'msg' => '删除成功'
        ];
    }else{
        return $info = [
            'status' => 0,
            'msg' => '删除失败'
        ];
    }
}
//加减改变商品数量
public function updateNum(Request $request){
    $data=$request->input(); 
    // var_dump($data);die;
    $cart_id=$data['cart_id'];
    $where=[
        'cart_id'=>$cart_id,
    ];
    $arr=DB::table("cart")->where($where)->first();
    // $arr=count($arr);
    // print_r($arr);die;
    $goods_id=$arr->goods_id;
    $where=[
        'goods_id'=>$goods_id,
    ];
    $res=DB::table("goods")->where($where)->first();
    $goods_prices=$res->goods_price;
    // var_dump($goods_prices);die;
    $num=$data['num'];
    if($num<1){
        $num=1;
    }
    $goods_pricess=$num*$goods_prices;
    $res=DB::table('cart')->where('cart_id','=',$cart_id)->update(['number'=>$num,"goods_prices"=>$goods_pricess]);
}
public function sub(Request $request){
    $goods_id=$request->input("goods_id");
    // 验证是否登录
    $uid = session("tel");
    $id=session("id");
    if(empty($uid)){
        return array("status"=>0,"msg"=>"需登录");die;
    }else{
    // 验证库存
    $arrGoods=array();
    $arrGoodsNum=DB::table("cart")->select(['goods_id','number'])->whereIn("goods_id",$goods_id)->get();
    foreach($arrGoodsNum as $key=>$value){
        $arrGoods[$value->goods_id]=$value->number;
    }
    $bol=true;
    foreach($arrGoods as $key=>$val){
        $info=DB::table('cart')->select()->where('goods_id',$key)->get();
        if(!count($info)){
           $bol=false;
        } 
    }
    if(!$bol){
        $arr=array("status"=>2,"msg"=>"库存为空");
        return $arr;die;

    }
    // 订单号
    $order_no=date("YmdHis",time()).rand(1000,9999);
    // 总金额
    $ids=implode(",",$goods_id);
    $sql="select sum(goods_price) as total from goods where goods_id in ({$ids})";
    $arrInfo=DB::select($sql);
    $order_amount=$arrInfo[0]->total;
    $time=time();
    $arr=array(
        'order_no'=>$order_no,
        'user_id'=>$id,
        'order_amount'=>$order_amount,
        'order_pay_type'=>1,
        'pay_status'=>2,
        'pay_way'=>2,
        'status'=>1,
        'ctime'=>$time,
    );
    $orderbol=DB::table("shop_order")->insertGetId($arr);
    $sql="update cart set status=2 where goods_id in ($ids) and user_id=$uid";
    $arr=DB::select($sql);
    if(!empty($orderbol)){
    $cart=Cart::join('goods','goods.goods_id','=','cart.goods_id')->whereIn('goods.goods_id',$goods_id)->get();
    $time=time();
    foreach ($cart as $k=>$v){
        $arr[]=[
            'order_id'=>$orderbol,
            'goods_id'=>$v->goods_id,
            'goods_name'=>$v->goods_name,
            'order_no'=>$order_no,
            'user_id'=>$id,
            'goods_price'=>$v->goods_price,
            'goods_image'=>$v->goods_img,
            'buy_number'=>$v->number,
            'goods_price'=>$v->goods_prices,
            'comnent_status'=>1,
            'ctime'=>$time,
            'status'=>1,
        ];
    }
    $arr=DB::table('shop_order_detail')->insert($arr);
    if($arr==true){
        return array("status"=>3,"msg"=>"正在结算中",'order_id'=>$orderbol);
    }
    }
   
}
}
// 结算
public function payment(Request $request){
    $order_id=$request->input('order_id');
    $arr=DB::table("shop_order_detail")->where('order_id',$order_id)->get();
    $res=DB::table("shop_order")->where('order_id',$order_id)->first();
    // $order_amount=$res->order_amount;
    // var_dump($order_amount);die;
    return view('index.payment',['arr'=>$arr,'res'=>$res]);
}
// 支付
public function dopayment(Request $request){
    $order_id=$request->input("order_id");
    // var_dump($order_id);die;
    $where=[
        'order_id'=>$order_id,
    ];
    $arr=DB::table("shop_order_address")->where($where)->first();
    $arr=count($arr);
    // var_dump($arr);die;
    if($arr==0){
        return array("status"=>1,"msg"=>"请添加收货地址",'order_id'=>$order_id);
    }
}
public function address(Request $request){
    $order_id=$request->input("order_id");
      $user_id=session('id');
      $where=[
        'user_id'=>$user_id,
        'is_del'=>1,
      ];
      $arrInfo=DB::table('shop_order_address')->where($where)->get();
      return view("index/address",['arrInfo'=>$arrInfo,'order_id'=>$order_id]);
}
public function writeaddr(Request $request){
    $order_id=$request->input("order_id");
    return view("index/writeaddr",['order_id'=>$order_id]);
 }
 public function address_do(Request $request){
    $data=$request->input();
    // dump($data);die;
    $user_id=$user_id=$request->session()->get('id');
    if(empty($user_id)){
        echo json_encode(['code'=>2,'msg'=>'请先登录！']);die;
    }
    $data['user_id']=$user_id;
    $data['ctime']=time();
    $res=DB::table('shop_order_address')->insert($data);
    if($res){
        echo json_encode(['code'=>1,'msg'=>'添加成功']);
    }else{
        echo json_encode(['code'=>0,'msg'=>'添加失败']);
    }
}
public function  add_del(Request $request){
    $id=$request->input('id');
    $all=DB::table('shop_order_address')->where('id',$id)->get()->toArray()[0];
//        dump($all);die;
    if($all->is_default==1){
        return json_encode([
            'code'=>0,
            'msg'=>'请先修改默认地址，再次删除'
        ]);
    }
    $res=DB::table('shop_order_address')->where('id',$id)->update(['is_del'=>2]);
    if($res){
        return json_encode([
            'code'=>1,
            'msg'=>'删除成功'
        ]);
    }else{
        return json_encode([
            'code'=>0,
            'msg'=>'删除失败'
        ]);
    }
}

public function edit(Request $request){
    $id=$request->input('id');
    // print_R($address_id);exit;
    $res=DB::table('shop_order_address')->where('id',$id)->get();
    // print_R($res);exit;
    return view('index/edit',['addressInfo'=>$res]);
}


public function address_update(Request $request){
    $data=$request->input();
    $id=$request->input("id");
    // print_r($order_id);exit;
    $data=[
      'order_receive_name'=>$data['order_receive_name'],
      'receive_phone'=>$data['receive_phone'],
      'city_id'=>$data['city_id'],
      'receive_address'=>$data['receive_address']
    ];
    $where=[
      'id'=>$id
    ];
    $res=DB::table('shop_order_address')->where($where)->update($data);
    if($res){
        echo json_encode(['code'=>1,'msg'=>'修改成功']);
    }else{
        echo json_encode(['code'=>0,'msg'=>'修改失败']);
    }
}
public function buyrecord(){
    $where=[
        'is_hot'=>1
    ];
    $res=DB::table("goods")->where($where)->get();
   
    return view("index.buyrecord",['res'=>$res]);
}
}
