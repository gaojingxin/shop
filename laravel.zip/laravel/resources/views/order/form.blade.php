<!doctype html>
<html lang="en">
<style>
    .qqq ul li{
        list-style: none;
        float: left;
        padding: 0 15px;
    }
</style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.js"></script>
</head>
<body><form class="add_form">
是否上架：<select name="search" action="form">
    <option value="">--请选择--</option>
    <option name=is_sale value="1">是</option>
    <option value="2">否</option>
</select>
是否热卖：<select name="" id="">
    <option value="">--请选择--</option>
    <option value="1">是</option>
    <option value="2">否</option>
</select>

    <table border="1">
        <tr>
            <td>商品id</td>
            <td>分类</td>
            <td>名称</td>
            <td>描述</td>
            <td>是否热卖</td>
            <td>是否上架</td>
            <td>操作</td>
        </tr>
        <?php foreach($arr as $k=>$v){?>
        <tr>
            <td>{{$v->user_id}}</td>
            <td>{{$v->name}}</td>
            <td><input type="text" value="{{$v->user_name}}" id="{{$v->user_id}}" class="name"></td>
            <td>{{$v->user_content}}</td>
            <td>{{$v->is_hot}}</td>
            <td>{{$v->is_sale}}</td>
            <td> <a href="update?user_id={{$v->user_id}}">修改</a>
                <a href="javascript:;" name="del" id="{{$v->user_id}}">删除</a></td>
        </tr>
        <?php }?>
    </table>
</form>
</body>
</html>
<div class="qqq">{{ $arr->links() }}</div>
<script src="/js/jquery.js"></script>
<script>
    $(function(){
        $("[name='del']").click(function(){
            var _this=$(this);
            var goods_id=_this.attr('id');
            if(confirm('是否删除？')){
                $.post('delete',{id:goods_id},function(res){
                    if(res==1){
                        alert('删除成功');
                        _this.parents('tr').remove();
                    }else{
                        alert('删除失败');
                    }
                });
            }
        });
        // 即点即改
        $('.name').blur(function(){
        var str=$(this).val();
        var obj=$(this);
        var id=$(this).attr('id');
        $.ajax({
            method: "POST",
            url: "upname",
            data: 'user_name='+str+'&id='+id,
        }).done(function( msg ) {
            console.log(msg);
            if(msg==1){
                alert('修改成功');
                history.go(0);
            }else{
                alert('修改失败');
            }
        });
    });
    })
</script>