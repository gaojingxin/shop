<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('hello',function(){
	return 'Routes\web.php 中配置路由';
});
// Route::get("show","UserController@show");
// Route::get("add","order\OrderController@show");
// Route::get("show/{id}",function($id){
 
//         return view("order\OrderController@show");
  
// });
// Route::get("show","order\OrderController@show");
// Route::post("doadd","order\OrderController@doadd");
// Route::get("form","order\OrderController@form");
// Route::post("delete","order\OrderController@delete");
// Route::get("user","order\OrderController@user");
// Route::get("update","order\OrderController@update");
// Route::post("update_do","order\OrderController@update_do");
// Route::post("upname","order\OrderController@upname");



Route::get("index","index\IndexController@index");
Route::get("user","user\UserController@user");
Route::post("doadd","user\UserController@doadd");
Route::get("login","user\UserController@login");
Route::post("dologin","user\UserController@dologin");
Route::get("userpage","user\UserController@userpage");
Route::post("getcode","user\UserController@getcode");
Route::get("demo","user\UserController@demo");
Route::post("addli","index\IndexController@addli");
Route::get("allshops","index\IndexController@allshops");
Route::post("test","index\IndexController@test");
Route::get("shopContent","index\IndexController@shopContent");
Route::post("shopcart","index\IndexController@shopcart");
Route::get("docart","index\IndexController@docart");
Route::get("quit","index\IndexController@quit");
Route::get("userpage","index\IndexController@userpage");
Route::post("cart_del","index\IndexController@cart_del");
Route::post("updateNum","index\IndexController@updateNum");
Route::post("sub","index\IndexController@sub");
Route::get("payment","index\IndexController@payment");
Route::post("dopayment","index\IndexController@dopayment");
Route::get("address","index\IndexController@address");
Route::get("writeaddr","index\IndexController@writeaddr");
Route::post("address_do","index\IndexController@address_do");
Route::post("add_del","index\IndexController@add_del");
Route::get("edit","index\IndexController@edit");
Route::post("address_update","index\IndexController@address_update");
Route::get("buyrecord","index\IndexController@buyrecord");












