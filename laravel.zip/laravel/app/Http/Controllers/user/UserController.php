<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\models\user;
use Illuminate\Support\Facades\DB;
class UserController extends Controller
{
    //注册
    public function user(){
        return view("User.register");
    } 
    public function doadd(Request $request){
        $arr=$request->input();
        $tel=$arr['tel'];
        $pwd=$arr['pwd'];
        $conpwd=$arr['conpwd'];
        $code=$arr['code'];
        if($pwd!=$conpwd){
            $arr=array(
                'status'=>0,
                "msg"=>"密码不一致",
            );
            return $arr;
        }
       // 验证唯一
       $arr=user::where("tel",$tel)->first();
       if(!empty($arr)){
           $arr=array(
               'status'=>0,
               "msg"=>"手机号不能重复",
           );
           return $arr;
       }
            // 验证验证码
            $time=time();
            $sql=DB::table("code")
            ->select("*")
            ->where("code",$code)
            ->where("timeout",">",$time)
            ->where("tel",$tel)
            ->where("status",1)
            ->first();

            if(empty($sql->id)){
                $arr=array(
                    'status'=>0,
                    "msg"=>"验证码错误",
                );
                return $arr;
            }   
            $id=$sql->id;         
            $pwd=md5($pwd);
            $arrInfo=array(
                    'tel'=>$tel,
                    'pwd'=>$pwd,
            );
             $bol=DB::table("user")->insert($arrInfo);
            //  dump($bol);
            if($bol){
                $arr=array(
                    'status'=>1,
                    "msg"=>"注册成功",
                );
                return $arr;
                DB::table("code")->where('id',$id)->update(['status'=>0]);
            }else{
                $arr=array(
                    'status'=>0,
                    "msg"=>"失败",
                );
                return $arr;
            }

        }
        // 登录
        public function login(){
            return view("User.login");
        }
        public function dologin(Request $request){
            $arr=$request->input();
            $tel=$arr['tel'];
            $pwd=$arr['pwd'];
            $pwd=md5($pwd);
            $data=['tel'=>$tel,'pwd'=>$pwd];
            $user=DB::table("user")->where($data)->first();
            if($user){
                $id=$user->id;
                $tel=$user->tel;
              
                session(['id'=>$id,"tel"=>$tel]);
                return array("status"=>1,"msg"=>"登陆成功");
            }else{
                return array("status"=>0,"msg"=>"登陆失败");
            }

        }
        public function userpage(){
            return view('User.userpage');
        }
        public function getcode(Request $request){
            $tel = $request->input("tel");
            $num = rand(1000,9999); 
            $obj=new \send();
            $bol=$obj->show($tel,$num);
            if($bol==100){
                //连接数据库
                $arr=array(
                    'code'=>$num,
                    'tel'=>$tel,
                    'timeout'=>time()+240,
                    'status'=>1,
            );
          
            $bol=DB::table("code")->insert($arr);
            var_dump($bol);
            }
           
        }
        public function demo(){
            return view("User.demo");
        }
     
}
